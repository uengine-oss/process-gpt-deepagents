"""Local replacements for SDK AgentExecutor, RequestContext, and EventQueue."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Literal

TaskState = Literal["working", "completed"]


class RequestContext:
    """Context for a single task (replaces SDK RequestContext)."""

    def __init__(self, task_row: dict[str, Any]) -> None:
        self._row = task_row
        extras = task_row.get("extras")
        if isinstance(extras, str):
            import json
            try:
                extras = json.loads(extras)
            except Exception:
                extras = {}
        self._extras = extras or {}

    def get_user_input(self) -> str:
        """Return the user task content (query)."""
        return (
            self._row.get("description")
            or self._row.get("name")
            or self._row.get("title")
            or self._row.get("user_input")
            or ""
        )

    def get_context_data(self) -> dict[str, Any]:
        """Return row and extras for the executor."""
        return {"row": self._row, "extras": self._extras}


class EventQueue:
    """In-memory event queue (replaces SDK EventQueue)."""

    def __init__(self) -> None:
        self.events: list[dict[str, Any]] = []

    def enqueue_event(self, event: dict[str, Any]) -> None:
        self.events.append(event)


def new_agent_text_message(
    text: str,
    proc_inst_id: str,
    task_id: str,
) -> str:
    """Build message string for status events (A2A-style)."""
    return text


def new_text_artifact(
    name: str,
    description: str,
    text: str,
) -> dict[str, Any]:
    """Build artifact dict for TaskArtifactUpdateEvent."""
    return {"name": name, "description": description, "text": text}


class AgentExecutor(ABC):
    """Abstract executor interface (replaces SDK AgentExecutor)."""

    @abstractmethod
    async def execute(
        self,
        context: RequestContext,
        event_queue: EventQueue,
    ) -> str:
        """Run the task. Returns the draft result string (JSON) to write to DB."""
        ...

    async def cancel(
        self,
        context: RequestContext,
        event_queue: EventQueue,
    ) -> None:
        """Called when the task is cancelled."""
        pass
